package com.wagenhaus.rest.webservices.restfulwebservices.wagenhaus;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class WagenHardcodedService {

	private static List<Wagen> wagens = new ArrayList<>();
	private static long idCounter = 0;

	static {
		wagens.add(new Wagen(++idCounter, "Polo", " Rs. 6.16 - 9.99 Lakh | 999 cc | 18 kmpl | Petrol", new Date(), false));
		wagens.add(new Wagen(++idCounter, "Vento", "Rs. 9.99 - 13.83 Lakh | 1598 cc | 18 kmpl | Petrol", new Date(), false));
		wagens.add(new Wagen(++idCounter, "Tiguan", "Rs. 34.20 Lakh | 1984 cc | 17 kmpl | Diesel", new Date(), false));
		wagens.add(new Wagen(++idCounter, "Kushaq(coming soon)", "Rs 10.51 Lakh onwards| 999 cc | 18 kmpl | Petrol", new Date(), false));
	}

	public List<Wagen> findAll() {
		return wagens;
	}
	
	public Wagen save(Wagen wagen) {
		if(wagen.getId()==-1 || wagen.getId()==0) {
			wagen.setId(++idCounter);
			wagens.add(wagen);
		} else {
			deleteById(wagen.getId());
			wagens.add(wagen);
		}
		return wagen;
	}

	public Wagen deleteById(long id) {
		Wagen wagen = findById(id);

		if (wagen == null)
			return null;

		if (wagens.remove(wagen)) {
			return wagen;
		}

		return null;
	}

	public Wagen findById(long id) {
		for (Wagen wag : wagens) {
			if (wag.getId() == id) {
				return wag;
			}
		}

		return null;
	}

}
