import React, { Component } from 'react'

import WagenDataService from '../../api/WagenDataService.js'
import AuthenticationService from './AuthenticationService'
import moment from 'moment'

class ListWagenComponent extends Component{
    constructor(props){
        super(props)
        
            this.state={
                wagens:[
                   // {id:1, name: 'PEGANI HAURYA BC', available: true, ManufacturingDate: new Date()},
                   // {id:2, name: 'FERRARI PININFARINA SERGIO', available: true, ManufacturingDate: new Date()},
                   // {id:3, name: 'ASTON MARTIN VALKYRIE', available: false, ManufacturingDate: new Date()},
                   // {id:4, name: 'BUGATTI VEYRON', available: true, ManufacturingDate: new Date()},
                   // {id:5, name: 'LYKAN HYPERSPORT',available: false, ManufacturingDate: new Date()},
                   // {id:6, name: 'MACLAREN',available: true, ManufacturingDate: new Date()}

                ], 
                message:null


            }
            this.deleteWagenClicked = this.deleteWagenClicked.bind(this)
            this.updateWagenClicked = this.updateWagenClicked.bind(this)
            this.addWagenClicked = this.addWagenClicked.bind(this)
            this.refreshWagens = this.refreshWagens.bind(this)
    
        

    }


    componentDidMount() {
        console.log('componentDidMount')
        this.refreshWagens();
        console.log(this.state)
    }

    refreshWagens() {
        let username = AuthenticationService.getLoggedInUserName()
        WagenDataService.retrieveAllWagens(username)
            .then(
                response => {
                   // console.log(response);
                    this.setState({ wagens: response.data });
                }
            )
    }

    componentWillUnmount() 
    {
        console.log('componentWillUnmount')
    }

    shouldComponentUpdate(nextProps, nextState) 
    {
        console.log('shouldComponentUpdate')
        console.log(nextProps)
        console.log(nextState)
        return true
    }

  

    deleteWagenClicked(id) 
    {
        let username = AuthenticationService.getLoggedInUserName()
        //console.log(id + " " + username);
        WagenDataService.deleteWagen(username, id)
            .then(
                response => {
                    this.setState({ message: `Delete of car ${id} Successful` })
                    this.refreshWagens()
                }
            )

    }

    addWagenClicked() {
        this.props.history.push(`/wagens/-1`)
    }

    updateWagenClicked(id) {
        console.log('update ' + id)
        this.props.history.push(`/wagens/${id}`)
        // /wagens/${id}
        // let username = AuthenticationService.getLoggedInUserName()
        // //console.log(id + " " + username);
        // WagenDataService.deleteWagen(username, id)
        //  .then (
        //      response => {
        //         this.setState({message : `Delete of wagen ${id} Successful`})
        //         this.refreshWagens()
        //      }
        //  )



    }

   

    render()
    {
        return (
            <div>
            <h1>Volkswagen Top Cars in India</h1>
            {this.state.message && <div class="alert alert-success">{this.state.message}</div>}
            <div className="container">
            <table className="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Availability</th>
                        <th>Manufacturing Date</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        this.state.wagens.map
                        (
                            wagen =>
                            <tr key={wagen.id}>
                         <td>{wagen.id}</td>
                         <td>{wagen.name}</td>
                         <td>{wagen.description}</td>
                         <td>{wagen.available.toString()}</td>
                        <td>{moment(wagen.manufacturingDate).format('YYYY-MM-DD')}</td>
                        <td><button className="btn btn-success" onClick={() => this.updateWagenClicked(wagen.id)}>Update</button></td>
                        <td><button className="btn btn-warning" onClick={() => this.deleteWagenClicked(wagen.id)}>Delete</button></td>
                        </tr>
                        )
                         
                    }
                   
                </tbody>

            </table>
            <div className="row">
            <button className="btn btn-success" onClick={this.addWagenClicked}>Add</button>
                    </div>
            </div>
            </div>
        )
    }

}

export default ListWagenComponent