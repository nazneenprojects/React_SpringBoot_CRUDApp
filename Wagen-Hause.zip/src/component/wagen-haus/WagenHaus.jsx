import React, {Component} from  'react'
import './WagenHaus.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import AuthenticatedRoute from './AuthenticatedRoute'
import LoginComponent from './LoginComponent'
import ListWagenComponent from './ListWagenComponent'
import HeaderComponent from './HeaderComponent';
import WelcomeComponent from './WelcomeComponent'
import FooterComponent from './FooterComponent';
import ErrorComponent from './ErrorComponent';
import WagenComponent from './WagenComponent';

class WagenHaus extends Component{

    render()
    {
         return(
            <div>
            
            <Router>
                <>
                <HeaderComponent/>
                <Switch>
                <Route path="/"exact component={LoginComponent}/>
                <Route path="/login" component={LoginComponent}/>
                <AuthenticatedRoute path="/welcome/:name" component={WelcomeComponent}/>
                <AuthenticatedRoute path="/wagen" component={ListWagenComponent}/>
                <AuthenticatedRoute  path="/logout" component={LogoutComponent}/>
                <AuthenticatedRoute  path="/wagen:id" component={WagenComponent}/>
                <Route component={ErrorComponent}/>
                </Switch>
                <FooterComponent/>
                </>
            </Router>
           {/*
            {LoginComponent}
            {WelcomeComponent}
            */}
            </div>
            
         );

    }
}







class LogoutComponent extends Component {
    render() {
        return (
            <>
                <h1>You are logged out</h1>
                <div className="container">
                    Thank You for Using Our Application.
                </div>
            </>
        )
    }
}


export default WagenHaus