
import React, {Component} from  'react'

class ErrorComponent extends Component
{
    render(){
        return (
            <div>This Page you are looking is not available! Please go to Home page </div> 
        );
        }

}

export default ErrorComponent