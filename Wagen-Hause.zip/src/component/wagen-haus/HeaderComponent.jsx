import React, { Component } from 'react'
import {withRouter ,  Link} from 'react-router-dom'
import AuthenticationService from './AuthenticationService.js'

class HeaderComponent extends Component {
    render(){
        const isUserLoggedIn = AuthenticationService.isUserLoggedIn();
        return(
 
            <header>
            <nav className="navbar navbar-expand-md navbar-dark bg-dark">
                <div><a href="/" className="navbar-brand">Wagen-Haus</a></div>
                <ul className="navbar-nav">
                    {/* <li><Link className="nav-link" to="/welcome/Naz">Home</Link></li>
                    <li><Link className="nav-link" to="/wagen">Car Collection</Link></li> */}
                   {isUserLoggedIn && <li><Link className="nav-link" to="/welcome/Naz">Home</Link></li>}
                    {isUserLoggedIn && <li><Link className="nav-link" to="/wagen">New Cars</Link></li>} 
                </ul>
                <ul className="navbar-nav navbar-collapse justify-content-end">
                {/* <li><Link className="nav-link" to="/login">Login</Link></li>
                <li><Link className="nav-link" to="/logout" onClick={AuthenticationService.logout}>Logout</Link></li> */}
                    {!isUserLoggedIn && <li><Link className="nav-link" to="/login">Login</Link></li>}
                    {isUserLoggedIn && <li><Link className="nav-link" to="/logout" onClick={AuthenticationService.logout}>Logout</Link></li>} 
                </ul>
            </nav>
        </header>
        );
    }
}

export default withRouter(HeaderComponent);