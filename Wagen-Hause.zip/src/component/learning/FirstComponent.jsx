import React, { Component } from 'react';

 class FirstComponent extends Component {
    render() {
      return (
        <div className="App">
          My First Comp
        </div>
      );
    }
  }

  export default FirstComponent