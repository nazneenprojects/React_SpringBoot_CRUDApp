import React from 'react';

 function ThirdComponent(){

    return (
      <div className="App">
        My Third Comp
      </div>
    );
  
  }

  export default ThirdComponent