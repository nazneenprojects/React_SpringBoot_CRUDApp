import React, { Component } from 'react';

 class SecondComponent extends Component {
    render() {
      return (
        <div className="App">
          My Second Comp
        </div>
      );
    }
  }
  export default SecondComponent