import axios from 'axios'

class WagenDataService{

    retrieveAllWagens(name) {
        console.log('executed service')
        return axios.get(`http://localhost:8083/users/${name}/wagens`);
    }

    

    retrieveWagen(name, id) {
        //console.log('executed service')
        return axios.get(`http://localhost:8083/users/${name}/wagens/${id}`);
    }

    deleteWagen(name, id) {
        //console.log('executed service')
        return axios.delete(`http://localhost:8083/users/${name}/wagens/${id}`);
    }

    updateWagen(name, id, wagen) {
        //console.log('executed service')
        return axios.put(`http://localhost:8083/users/${name}/wagens/${id}`, wagen);
    }

    createWagen(name, wagen) {
        //console.log('executed service')
        return axios.post(`http://localhost:8083/users/${name}/wagens`, wagen);
    }


}


export default new WagenDataService()
